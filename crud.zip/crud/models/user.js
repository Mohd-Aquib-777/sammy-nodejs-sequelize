module.exports = (sequelize,Sequelize)=>{
    const user = sequelize.define('user', {
        name: {
            type: Sequelize.STRING,
            field: 'name'
        },
        email: {
            type: Sequelize.STRING,
            field: 'email'
        },
        mobile: {
            type: Sequelize.STRING,
            field: 'mobile'
        }
    }
    // {
    //     freezeTableName: true // Model tableName will be the same as the model name
    // }
    );
    return user;
}
