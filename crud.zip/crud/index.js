const express = require('express');

const app = express();

const path = require('path');

var router = express.Router();

const port = process.env.port || 8000;

const bodyParser = require('body-parser');

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({ extended: true }));

app.use(bodyParser.json());

const routes = require('./routes/index.js');

app.use(express.static("public"));

app.use('/',routes);

app.get('/sammy',(req,res)=>{
    res.status(200).render('sammyExample');
})

app.listen(port, () => {
    console.log('server is running on ' + port);
});
