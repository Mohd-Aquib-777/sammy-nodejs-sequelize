;(function($) {
    var app = $.sammy(function() {
      this.get('/', function() {
        $('#main').text('');
      });
      //=======for fetching data========   
      this.get('/test', function(arg){
          $.ajax({
              url:'/fetchData',
              type:'post',
              dataType:'json',
              success:function(res){
                //   console.log(res)
                  var appendInTable='';
                  for(val in res)
                  {
                      appendInTable+="<tr>";
                      appendInTable+="<td>"+(parseInt(val)+1)+"</td>";
                      appendInTable+="<td>"+res[val].name+"</td>";
                      appendInTable+="<td>"+res[val].email+"</td>";
                      appendInTable+="<td>"+res[val].mobile+"</td>";
                      appendInTable+='<td>\
                      <form action="/deleteUser" class="editForm p-1" method="post">\
                          <input type="hidden" name="id" value="'+res[val].id+'">\
                          <input type="submit" class="btn btn-danger" value="delete">\
                      </form><form action="/fetchUser" class="editForm p-1" method="post">\
                          <input type="hidden" name="id" value="'+res[val].id+'">\
                          <input type="submit" class="btn btn-warning" value="Edit">\
                      </form></td>';
                      //onclick="updateUser(`'+res[val].id+'`)"    
                      appendInTable+="</tr>";    
                  }
                  $("tbody").html(appendInTable);
                  
                  $('#example').DataTable({
                      dom: 'Bfrtip',
                      //     buttons: [
                      //         'copy', 'csv', 'excel', 'pdf', 'print'
                      //     ],
                      retrieve: true,
                      ServerSide: true,
                      "destroy": true,
                  });   
               }
          });
        });

        // =============for delete and fetching data======
        this.post('/deleteUser', function(arg){
            var id = this.params['id'];
            $.ajax({
                url:'/deleteUserBySammy',
                type:'post',
                dataType:'json',
                data:{id:id},
                success:function(res){
                    // console.log(res);
                    var appendInTable='';
                    for(val in res)
                    {
                        appendInTable+="<tr>";
                        appendInTable+="<td>"+(parseInt(val)+1)+"</td>";
                        appendInTable+="<td>"+res[val].name+"</td>";
                        appendInTable+="<td>"+res[val].email+"</td>";
                        appendInTable+="<td>"+res[val].mobile+"</td>";
                        appendInTable+='<td>\
                        <form action="/deleteUser" class="editForm p-1" method="post">\
                          <input type="hidden" name="id" value="'+res[val].id+'">\
                          <input type="submit" class="btn btn-danger" value="delete">\
                      </form><form action="/fetchUser" class="editForm p-1" method="post">\
                            <input type="hidden" name="id" value="'+res[val].id+'">\
                            <input type="submit" class="btn btn-warning" value="Edit">\
                        </form></td>';    
                        appendInTable+="</tr>";    
                    }
                    // console.log(appendInTable);
                    $("tbody").html(appendInTable);
                    
                    $('#example').DataTable({
                        dom: 'Bfrtip',
                        //     buttons: [
                        //         'copy', 'csv', 'excel', 'pdf', 'print'
                        //     ],
                        retrieve: true,
                        ServerSide: true,
                        "destroy": true,
                    });   
                }
            });
            $('#main').text('Hello World');
        });

        // =============for add and fetching data======
        this.post('/addUser', function(arg){
            var name = this.params['name'];
            var email = this.params['email'];
            var phone = this.params['phone'];
            // console.log(name);
            // debugger;
            $.ajax({
                url:'/addUserBySammy',
                type:'post',
                dataType:'json',
                data:{name:name,email:email,phone:phone},
                success:function(res){
                    // console.log(res);
                    var appendInTable='';
                    for(val in res)
                    {
                        appendInTable+="<tr>";
                        appendInTable+="<td>"+(parseInt(val)+1)+"</td>";
                        appendInTable+="<td>"+res[val].name+"</td>";
                        appendInTable+="<td>"+res[val].email+"</td>";
                        appendInTable+="<td>"+res[val].mobile+"</td>";
                        appendInTable+='<td>\
                        <form action="/deleteUser" class="editForm p-1" method="post">\
                          <input type="hidden" name="id" value="'+res[val].id+'">\
                          <input type="submit" class="btn btn-danger" value="delete">\
                      </form><form action="/fetchUser" class="editForm p-1" method="post">\
                            <input type="hidden" name="id" value="'+res[val].id+'">\
                            <input type="submit" class="btn btn-warning" value="Edit">\
                        </form></td>';    
                        appendInTable+="</tr>";    
                    }
                    // console.log(appendInTable);
                    $("tbody").html(appendInTable);
                    
                    $('#example').DataTable({
                        dom: 'Bfrtip',
                        //     buttons: [
                        //         'copy', 'csv', 'excel', 'pdf', 'print'
                        //     ],
                        retrieve: true,
                        ServerSide: true,
                        "destroy": true,
                    });   
                }
            });
            $('form')[0].reset();
        });

        // =============for  fetching by Id data======
        this.post('/fetchUser', function(arg){

            var id = this.params['id'];
            $.ajax({
                url:'updateUser',
                type:'post',
                data:{id:id},
                beforeSend:function()
                {
                    $("#loader").show();  
                },
                success:function(res)
                {
                    $("#loader").hide();
                    // console.log(res);
                    $('#showModal').trigger("click");
                    $("#editForm input[name=name]").val(res.name);
                    $("#editForm input[name=email]").val(res.email);
                    $("#editForm input[name=phone]").val(res.mobile);
                    $("#editForm input[name=id]").val(res.id);
                }
            });
        });

        // =============for update and fetching data======
        this.post('/editUser', function(arg){
            var name = this.params['name'];
            var email = this.params['email'];
            var phone = this.params['phone'];
            var id = this.params['id'];
            $.ajax({
                url:'updateUserBySammy',
                type:'post',
                data:{name:name,email:email,phone:phone,id:id},
                beforeSend:function()
                {
                    $("#loader").show();  
                },
                success:function(res)
                {
                    $("#loader").hide();
                    console.log(res);
                    var appendInTable='';
        
                    for(val in res)
                    {
                        appendInTable+="<tr>";
                        appendInTable+="<td>"+(parseInt(val)+1)+"</td>";
                        appendInTable+="<td>"+res[val].name+"</td>";
                        appendInTable+="<td>"+res[val].email+"</td>";
                        appendInTable+="<td>"+res[val].mobile+"</td>";
                        appendInTable+='<td>\
                        <form action="/deleteUser" class="editForm p-1" method="post">\
                        <input type="hidden" name="id" value="'+res[val].id+'">\
                        <input type="submit" class="btn btn-danger" value="delete">\
                        </form><form action="/fetchUser" class="editForm p-1" method="post">\
                                    <input type="hidden" name="id" value="'+res[val].id+'">\
                                    <input type="submit" class="btn btn-warning" value="Edit">\
                                </form></td>';    
                        appendInTable+="</tr>";    
                    }
                    $('tbody').html(appendInTable);
                    $('#example').DataTable({
                        dom: 'Bfrtip',
                        //     buttons: [
                        //         'copy', 'csv', 'excel', 'pdf', 'print'
                        //     ],
                        retrieve: true,
                        ServerSide: true,
                        "destroy": true,
                    });
                    $('#showModal').trigger("click");  
                }
            });
            $('#main').text('Hello World');
        });
    });

    $(function() {
      app.run()
    });
})(jQuery);