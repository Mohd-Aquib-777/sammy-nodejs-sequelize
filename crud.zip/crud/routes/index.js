const express = require('express');

const router = express.Router();

const userController = require('../controller/userController');

router.route('/')
.get(userController.getData);

router.route('/addUser')
.post(userController.addUser);

router.route('/deleteUser/:id',)
.get(userController.deleteUser);

router.route('/updateUser')
.post(userController.getUserDetail);

router.route('/editUser')
.post(userController.updateUserDetail);

router.route('/fetchData')
.post(userController.updateUserDetail);

router.route('/deleteUserBySammy')
.post(userController.deleteUserBySammy);

router.route('/addUserBySammy')
.post(userController.addUserBySammy);

router.route('/updateUserBySammy')
.post(userController.updateUserBySammy);

module.exports = router;
