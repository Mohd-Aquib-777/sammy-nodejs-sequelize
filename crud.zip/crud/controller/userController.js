const userQuery = require('../dao/userQuery.js');

module.exports.getData = async (req,res)=>{
    let data = await userQuery.getAllUserData();
    res.status(200).render('home',{data:data});
}

module.exports.addUser = async (req,res)=>{
    var name = req.body.name;
    var email = req.body.email;
    var mobile = req.body.phone;
    let data = await userQuery.addUser(name,email,mobile);
    await res.redirect('/');
}

module.exports.deleteUser = async (req,res)=>{
    let resp = await userQuery.deleteUser(req.params.id);
    await res.redirect('/');
}

module.exports.getUserDetail = (req,res)=>{
    let data = userQuery.getUserDetail(req.body.id);
    data
    .then((user)=>{
        res.status(200).send(user);
    })
    .catch((err)=>{
        res.status(404).send(err);
    });
}

module.exports.updateUserDetail = (req,res)=>{
    var name = req.body.name;

    var email = req.body.email;
    
    var mobile = req.body.phone;
    
    var id = req.body.id;
    
    let data = userQuery.updateUserDetail(name,email,mobile,id);
    
    data.then((result)=>{
        let data = userQuery.getAllUserData();
        data.then((user)=>{
           res.status(200).send(user);
        });  
    })
    .catch((err)=>{
        res.status(404).send(err)
    });
}

module.exports.getAllUserData = async (req,res)=>{
    let data = await userQuery.getAllUserData();
    res.status(200).send(data);
}

module.exports.deleteUserBySammy = async(req,res)=>{
    let resp = await userQuery.deleteUser(req.body.id);
    let data = await userQuery.getAllUserData();
    res.status(200).send(data);
}

module.exports.addUserBySammy = async (req,res)=>{
    var name = req.body.name;
    var email = req.body.email;
    var mobile = req.body.phone;
    let data1 = await userQuery.addUser(name,email,mobile);
    let data = await userQuery.getAllUserData();
    res.status(200).send(data);  
}

module.exports.updateUserBySammy = (req,res)=>{
    var name = req.body.name;

    var email = req.body.email;
    
    var mobile = req.body.phone;
    
    var id = req.body.id;
    
    let data = userQuery.updateUserDetail(name,email,mobile,id);
    
    data.then((result)=>{
        let data = userQuery.getAllUserData();
        data.then((user)=>{
           res.status(200).send(user);
        });  
    })
    .catch((err)=>{
        res.status(404).send(err)
    }); 
}