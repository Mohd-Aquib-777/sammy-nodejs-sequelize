const db = require('../dataBase');

const users = db.users;

module.exports.getAllUserData = async ()=>{
    return await users.findAll({});
}

module.exports.addUser = async (name,email,phone)=>{
    return await users.create(
        {   
            name:name, 
            email:email, 
            mobile:phone, 
        }
    );
}

module.exports.deleteUser = async (id)=>{
  return await users.destroy({
        where:{id:id}
    })
    
}

module.exports.getUserDetail = (id)=>{
    return users.findOne({
        where:{id:id}
    });
}

module.exports.updateUserDetail = (name,email,mobile,id)=>{
    return users.update(
        { 
            name: name,
            email: email, 
            mobile:mobile
        }, 
        {
            where:{id:id}
        },
    );
} 


